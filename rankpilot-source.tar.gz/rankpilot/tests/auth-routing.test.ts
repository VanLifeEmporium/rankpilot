import { describe, expect, it, vi } from "vitest";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { createStaticHandler, createStaticRouter, StaticRouterProvider } from "react-router";
import { loader as launchLoader } from "../app/routes/_index/route";

vi.mock("../app/shopify.server", () => ({
  authenticate: {
    admin: async () => {
      throw new Response('<script data-api-key="test-key" src="https://cdn.shopify.com/shopifycloud/app-bridge.js"></script>', {
        headers: { "Content-Type": "text/html" },
      });
    },
  },
}));
import { loader as authLoader, ErrorBoundary } from "../app/routes/auth.$";

describe("embedded app launch", () => {
  it("renders a public landing page without a Shopify launch", () => {
    const old = process.env.DEMO_MODE;
    process.env.DEMO_MODE = "false";
    try {
      expect(launchLoader({request: new Request("https://app.example/"), params: {}, context: {}, url: new URL("https://app.example/"), pattern: "/"})).toBeNull();
    } finally { if (old === undefined) delete process.env.DEMO_MODE; else process.env.DEMO_MODE = old; }
  });
  it("preserves Shopify launch parameters without changing the redirect origin", async () => {
    const query = "?shop=example.myshopify.com&host=encoded-host&embedded=1&id_token=test-token&return_to=https%3A%2F%2Fevil.example";
    const response = launchLoader({ request: new Request(`https://app.example/${query}`), params: {}, context: {}, url: new URL(`https://app.example/${query}`), pattern: "/" });
    if (!response) throw new Error("Expected launch redirect");
    expect(response.status).toBe(302);
    expect(response.headers.get("Location")).toBe(`/app${query}`);
  });
  it("renders Shopify's App Bridge response instead of a bare 200 error", async () => {
    const routes = [{ path: "/auth/*", loader: authLoader, ErrorBoundary }];
    const handler = createStaticHandler(routes);
    const context = await handler.query(new Request("https://app.example/auth/session-token"));
    if (context instanceof Response) throw new Error("Expected a routed response");
    const router = createStaticRouter(handler.dataRoutes, context);
    const html = renderToStaticMarkup(createElement(StaticRouterProvider, { router, context }));
    expect(html).toContain('<script data-api-key="test-key" src="https://cdn.shopify.com/shopifycloud/app-bridge.js"></script>');
    expect(html).not.toContain("Unexpected Application Error");
  });
});
