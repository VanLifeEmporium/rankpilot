import {it,expect} from 'vitest';
import {redirectAction} from '../app/core/redirects';
const previous={path:'/collections/old',target:'/collections/broken'};
const desired={path:previous.path,target:'/collections/live'};
it('repairs an existing mapping by update',()=>expect(redirectAction(previous,previous,desired)).toBe('update'));
it('restores the previous mapping on rollback',()=>expect(redirectAction(desired,desired,previous)).toBe('update'));
it('creates missing mappings and removes only its own new mapping on rollback',()=>{expect(redirectAction(null,null,desired)).toBe('create');expect(redirectAction(desired,desired,null)).toBe('delete')});
it('preserves a redirect edited by somebody else',()=>expect(()=>redirectAction({...desired,target:'/collections/newer'},desired,previous)).toThrow('Conflict'));
it('reconciles a retry after the remote mutation succeeded',()=>expect(redirectAction(desired,previous,desired)).toBe('none'));
