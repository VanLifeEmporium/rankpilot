import { describe, it, expect } from "vitest";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { createStaticHandler, createStaticRouter, StaticRouterProvider, useFormAction } from "react-router";

// Workspace uses this router-resolved action for every fetcher submission.
function Submission() {
  return createElement("form", { method: "post", action: useFormAction() });
}
const routes = [{ path: "/app", children: [
  { index: true, Component: Submission, action: () => ({ queued: "dashboard" }) },
  { path: ":section", Component: Submission, action: () => ({ queued: "section" }) },
] }];

describe("audit submission routing", () => {
  it.each([["/app", "dashboard"], ["/app/audit", "section"], ["/app/products", "section"]])("posts from %s to its action", async (path, target) => {
    const handler = createStaticHandler(routes);
    const context = await handler.query(new Request(`https://app.example${path}?shop=test.myshopify.com&host=test-host`));
    if (context instanceof Response) throw new Error("Unexpected redirect");
    const html = renderToStaticMarkup(createElement(StaticRouterProvider, { router: createStaticRouter(handler.dataRoutes, context), context }));
    const action = html.match(/action="([^"]+)"/)![1].replaceAll("&amp;", "&");
    const result = await handler.query(new Request(new URL(action, "https://app.example"), { method: "POST", body: new URLSearchParams({ intent: "audit" }) }));
    if (result instanceof Response) throw new Error("Unexpected response");
    expect(result.statusCode).toBe(200);
    expect(Object.values(result.actionData!)).toEqual([{ queued: target }]);
    expect(new URL(action,"https://app.example").searchParams.get("shop")).toBe("test.myshopify.com");
  });
});
