import {it, expect} from 'vitest';
import {secureDocument} from '../app/core/document-security';
it('denies framing when no Shopify policy exists', () => {
 const headers = new Headers();
 secureDocument(new Request('https://app.example'), headers);
 expect(headers.get('Content-Security-Policy')).toBe("frame-ancestors 'none'");
 expect(headers.get('Strict-Transport-Security')).toBe('max-age=31536000');
 expect(headers.get('Cache-Control')).toBe('no-store');
});
it('preserves the SDK shop-specific frame policy', () => {
 const policy = 'frame-ancestors https://example.myshopify.com https://admin.shopify.com;';
 const headers = new Headers({'Content-Security-Policy':policy});
 secureDocument(new Request('https://app.example?shop=evil.example'),headers);
 expect(headers.get('Content-Security-Policy')).toBe(policy);
});
it('does not set HSTS for local HTTP development', () => {
 const headers = new Headers();
 secureDocument(new Request('http://localhost:3000'),headers);
 expect(headers.has('Strict-Transport-Security')).toBe(false);
});
