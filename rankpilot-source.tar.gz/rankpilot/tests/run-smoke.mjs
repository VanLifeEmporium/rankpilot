import { spawn } from "node:child_process";
import {
  writeFileSync,
  mkdirSync,
  readFileSync,
  chmodSync,
  existsSync,
} from "node:fs";
import { brotliDecompressSync } from "node:zlib";
import { spawnSync } from "node:child_process";
import { setTimeout as wait } from "node:timers/promises";
import { chromium } from "@playwright/test";
import portableChromium from "@sparticuz/chromium";
process.loadEnvFile(".env");
const server = spawn(
  "node",
  ["./node_modules/@react-router/serve/bin.js", "./build/server/index.js"],
  {
    env: { ...process.env, PORT: "3000", HOST: "127.0.0.1" },
    stdio: ["ignore", "pipe", "pipe"],
  },
);
let logs = "";
server.stdout.on("data", (c) => (logs += c));
server.stderr.on("data", (c) => (logs += c));
const worker = spawn("node", ["--import", "tsx", "scripts/worker.ts"], {
  env: process.env,
  stdio: ["ignore", "pipe", "pipe"],
});
worker.stderr.on("data", (c) => (logs += c));
let browser, page;
try {
  for (let i = 0; i < 60; i++) {
    try {
      if ((await fetch("http://127.0.0.1:3000/health")).ok) break;
    } catch {}
    await wait(500);
    if (i === 59) throw new Error("Server did not start: " + logs);
  }
  const runtime = process.cwd() + "/.browser-runtime";
  mkdirSync(runtime, { recursive: true });
  const executablePath = runtime + "/chromium";
  if (!existsSync(executablePath)) {
    writeFileSync(
      executablePath,
      brotliDecompressSync(
        readFileSync("node_modules/@sparticuz/chromium/bin/chromium.br"),
      ),
    );
    chmodSync(executablePath, 0o755);
  }
  for (const name of ["fonts", "swiftshader"]) {
    const destination = name === "fonts" ? runtime + "/fonts" : runtime;
    mkdirSync(destination, { recursive: true });
    const tar = runtime + "/" + name + ".tar";
    writeFileSync(
      tar,
      brotliDecompressSync(
        readFileSync(
          "node_modules/@sparticuz/chromium/bin/" + name + ".tar.br",
        ),
      ),
    );
    spawnSync("tar", ["--no-same-owner", "-xf", tar, "-C", destination]);
  }
  writeFileSync(
    runtime + "/fonts/fonts.conf",
    `<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><dir>${runtime}/fonts/fonts</dir><dir>/usr/share/fonts</dir><cachedir>${runtime}/font-cache</cachedir></fontconfig>`,
  );
  process.env.FONTCONFIG_PATH = runtime + "/fonts";
  process.env.LD_LIBRARY_PATH =
    runtime +
    (process.env.LD_LIBRARY_PATH ? ":" + process.env.LD_LIBRARY_PATH : "");
  browser = await chromium.launch({
    executablePath,
    args: portableChromium.args.filter(
      (a) => !a.includes("disable-web-security"),
    ),
    headless: true,
  });
  const context = await browser.newContext({
    viewport: { width: 1440, height: 1100 },
  });
  page = await context.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("http://localhost:3000/app");
  await page
    .getByRole("heading", { name: "A clearer road to discovery" })
    .waitFor();
  mkdirSync("docs/screenshots", { recursive: true });
  await page.screenshot({
    path: "docs/screenshots/dashboard.png",
    fullPage: true,
  });
  await page.getByRole("link", { name: "Products", exact: true }).click();
  await page
    .getByRole("checkbox", {
      name: "Select Linen Blend Campervan Cushion",
      exact: true,
    })
    .check();
  await page
    .getByRole("button", { name: "Generate previews", exact: true })
    .click();
  await page.getByRole("link", { name: /Audit/, exact: false }).first().click();
  await page
    .getByRole("button", { name: "Review", exact: true })
    .first()
    .waitFor({ timeout: 30000 });
  await page
    .getByRole("button", { name: "Review", exact: true })
    .first()
    .click();
  await page.getByRole("button", { name: "Approve demo change" }).click();
  await page.waitForFunction(
    () =>
      document.body.textContent.includes("applied") ||
      document.body.textContent.includes("completed"),
    { timeout: 30000 },
  );
  await page.getByRole("link", { name: "Reports", exact: true }).click();
  await page
    .getByRole("button", { name: "Review", exact: true })
    .first()
    .click();
  await page
    .getByRole("button", { name: "Roll back this change" })
    .waitFor({ timeout: 30000 });
  await page.screenshot({
    path: "docs/screenshots/review.png",
    fullPage: true,
  });
  await page.getByRole("button", { name: "Roll back this change" }).click();
  await page.getByRole("link", { name: "Content", exact: true }).click();
  await page
    .getByRole("button", { name: "Create draft", exact: true })
    .first()
    .click();
  await page
    .getByText("Unpublished draft", { exact: true })
    .waitFor({ timeout: 30000 });
  await page.getByRole("link", { name: "AEO", exact: true }).click();
  await page
    .getByRole("heading", { name: "Independent answer-engine samples" })
    .waitFor();
  await page.getByRole("link", { name: "Settings", exact: true }).click();
  await page
    .getByRole("button", { name: "Save settings", exact: true })
    .click();
  await page.getByRole("status").filter({ hasText: "Saved." }).waitFor();
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("http://localhost:3000/app");
  await page.screenshot({
    path: "docs/screenshots/mobile.png",
    fullPage: true,
  });
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth > innerWidth,
  );
  if (overflow) throw new Error("Mobile horizontal overflow");
  if (errors.length) throw new Error("Browser errors: " + errors.join("; "));
  const liquid = readFileSync(
    "extensions/rankpilot-schema/blocks/rankpilot.liquid",
    "utf8",
  );
  const script = liquid.match(/<script>([\s\S]*?)<\/script>/)[1];
  const schemaInput = {
    pageType: "product",
    url: "https://example.com/products/lamp",
    root: "https://example.com",
    shop: "Test shop",
    title: "Lamp",
    description: "A lamp",
    currency: "GBP",
    product: {
      name: "Lamp",
      description: "A lamp",
      image: null,
      offers: [
        {
          "@type": "Offer",
          sku: "TEST",
          price: 12,
          availability: "https://schema.org/InStock",
        },
      ],
    },
    showFaqs: true,
    faqs: [{ question: "What is included?", answer: "One lamp" }],
    policiesVerified: false,
  };
  await page.setContent(
    '<div id="rankpilot-faqs">What is included? One lamp</div><script type="application/ld+json">' +
      JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Product",
        name: "Existing theme product",
      }) +
      '</script><script id="rankpilot-input" type="application/json">' +
      JSON.stringify(schemaInput) +
      "</script><script>" +
      script +
      "</script>",
  );
  await page.waitForFunction(() =>
    document.querySelector("script[data-rankpilot]"),
  );
  let graph = await page.evaluate(
    () =>
      JSON.parse(document.querySelector("script[data-rankpilot]").textContent)[
        "@graph"
      ],
  );
  if (
    graph.some((n) => n["@type"] === "Product") ||
    !graph.some((n) => n["@type"] === "FAQPage")
  )
    throw new Error("Schema ownership or FAQ generation failed");
  await page.evaluate(() => {
    const s = document.createElement("script");
    s.type = "application/ld+json";
    s.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: [],
    });
    document.head.appendChild(s);
  });
  await page.waitForFunction(
    () =>
      !JSON.parse(document.querySelector("script[data-rankpilot]").textContent)[
        "@graph"
      ].some((n) => n["@type"] === "FAQPage"),
  );
  console.log(
    "PASS: desktop/mobile workflows and schema deduplication, including late-added FAQ markup.",
  );
} catch (e) {
  console.error(e);
  if (page) {
    mkdirSync("docs/screenshots", { recursive: true });
    await page.screenshot({
      path: "docs/screenshots/error.png",
      fullPage: true,
    });
    console.error(
      await page.evaluate(() => ({
        body: document.body.outerHTML.slice(0, 1000),
        styles: [...document.querySelectorAll("body,.workspace,main,h1")].map(
          (e) => ({
            tag: e.tagName,
            rect: e.getBoundingClientRect().toJSON(),
            visibility: getComputedStyle(e).visibility,
            display: getComputedStyle(e).display,
            opacity: getComputedStyle(e).opacity,
          }),
        ),
      })),
    );
  }
  console.error(logs.slice(-6000));
  process.exitCode = 1;
} finally {
  if (browser) await browser.close();
  server.kill();
  worker.kill();
}
