# RankPilot implementation and boundaries

## Architecture

React Router serves both the embedded app and a standalone demo. The official `@shopify/shopify-app-react-router` library supplies App Bridge, install/authentication flows, authenticated Admin API clients, offline token refresh and webhook authentication. The API version is pinned to `2026-07`.

Prisma stores shop-isolated resources, credentials, audits, changes, jobs, events, observations and reports. Session access/refresh tokens and integration credentials are encrypted with AES-256-GCM. Every admin route authenticates independently; shop identity is derived from that authentication. Demo identity is a signed, HTTP-only cookie and cannot select a live tenant. Mutation requests require the configured app origin. No secret is sent back in a page loader.

The queue persists work, uses an atomic claim, has a lease heartbeat, retry/backoff and a delivery deduplication key. The supported topology is a single worker on the same persistent filesystem as the app. Shopify mutations use a restricted gateway; no arbitrary GraphQL executor is exposed in the UI. API cost/throttle information pauses background processing. Product/media connections are paginated. The outer catalogue connections are fully paginated.

Before a write or rollback, the worker reads the current remote field. An unexpected value produces a conflict. Multiple-image batches accept a mixture of their own before/after values on retry, so a partially applied batch can continue without overwriting unrelated changes. Shopify does not supply atomic compare-and-set for all product fields: an external writer could still change a value in the small interval between the read and mutation. Prefer maintenance windows for large competing supplier updates.

## Feature coverage

| Area | Behaviour | Boundary |
|---|---|---|
| Catalogue audit | Missing/long/duplicate metadata, short and supplier-style copy, missing image text, source image dimensions, duplicate descriptions, keywords and missing GTINs | Supplier-copy detection is a heuristic within this catalogue, not a web-wide plagiarism service. |
| Storefront audit | Page status, internal broken links, canonical tags, headings, JSON-LD syntax/selected required fields, response time, robots and llms.txt | Default 30 pages; configurable to 5,000. Up to 25 links per page; same-origin links only. Coverage and failures are recorded. HTTP timing is not Core Web Vitals. |
| Keywords | Curated UK clusters, page-specific assignment and duplicate-primary warnings | No fabricated search volume, difficulty, search demand or ranking promise. Search Console supplies real query evidence once connected. |
| Optimisation | Deterministic, fact-led copy, title cleanup, snippets, conservative image text, filenames, handles, related links and FAQs | Product/collection copy is currently composed from safe templates and verified facts, rather than a free-form LLM rewriting service. Model codes are preserved unless a reviewer changes the source title. Conservative alt text identifies the product; no visual image understanding is used. |
| Approvals | Preview, fact blockers, approve/reject, per-feature autopilot and version records | Editing verified facts invalidates pending copy previews. Approved work is processed by the worker. |
| URLs | Native Shopify handle redirects and explicit retired-collection redirects | A retired source must be absent from the imported collection catalogue. Destinations must be existing collections. Run a fresh audit first. |
| Blog engine | Five UK content-plan themes, answer-first draft structure, verified facts, product links and source list | Always unpublished. Drafts are starting points for editorial review, not independently researched buying-test conclusions. No external place/regulatory claims are generated. |
| Structured data | Product/Offer, Organization, WebSite, Article, BreadcrumbList and product FAQ JSON-LD | Emitted after JavaScript runs. Existing matching schema types take priority; existing theme/Judge.me Product nodes are not enriched or rewritten. Brand and review data are omitted when not verified. No review-ingestion adapter is included. |
| FAQ visibility | Approved FAQ data in an app-owned metafield, visibly rendered by the embed | The merchant must configure the expanded app namespace once and enable the embed. No extra FAQPage is added to an existing FAQ page. |
| Policy schema | GBP offers, GB shipping and returns when all settings are verified | Global shipping/returns settings must apply to every product. Otherwise leave them off. Do not infer delivery promises from a dropshipping app's name. |
| AI readiness | Crawler checks, Shopify-managed root file detection and downloadable discovery content | Does not edit theme code or replace root files. `/llms.txt` is a discovery convention, not a ranking guarantee. |
| Visibility | Six prompts per provider, answer/citation retention, precise citation host matching, cited-domain list and weekly trends | API samples are not exact consumer ChatGPT, Perplexity or Gemini UI rankings. Copilot/AI Overview observations are manual. |
| Analytics | Search Console page/query data; GA4 organic landing-page sessions and revenue; Bing page stats; Merchant product diagnostics; PageSpeed | Requires provider access. Search Console returns top query rows. Account-level shipping can satisfy a product-feed requirement. No feed write operations are used. |
| Reports | Weekly Markdown download, source-period comparison, change list, next priorities, mention trends | Correlation is not attribution. The scheduler is opt-in and requires a running worker. |
| Re-queue | Clicks down at least 25%, prior 100 impressions and 10 clicks, consecutive 28-day windows | 28-day change cooldown. Data is needed in both windows; sparse/new pages are not blindly rewritten. |
| Authority | Named UK research candidates and manual outreach drafts | No group joins, posts, messages or emails are sent. Current relevance and promotional rules require manual review. |

## Score definitions

The catalogue SEO score is an internal checklist index: `100 × (1 − min(findings, checks) / checks)`. Each resource contributes seven base checklist units; extra findings can lower the score. The score is bounded at zero and is not a search-engine quality or ranking measurement. The initial audit remains as a baseline in audit history.

“Answer-ready facts” is the percentage of dimensions, weight, materials and included-items fields confirmed for product resources. It is a narrow fact-completeness measure, not a claim to comprehensively measure AEO. Missing power/compatibility details still generate workflow blockers where relevant.

## Existing integrations

Judge.me and FAQ schema are detected in fetched HTML; the extension also examines live DOM JSON-LD. GA4 code presence is a hint, not proof that the account is connected. Search Console, Merchant Center and Bing ownership cannot reliably be inferred from HTML: their access is verified through the configured API credentials. No second feed or analytics tag is installed.

## Operations and recovery

- Errors appear in job state and event logs. Reports show connection failures without turning them into zero traffic.
- Approval and job creation are committed in one database transaction.
- Applied-field comparisons reconcile a retry after a process crash.
- Uninstall deletes stored sessions/credentials and cancels pending work. Privacy webhooks authenticate and purge shop data on `shop/redact`. The app does not import customer/order records.
- No automated email report sender is configured. Weekly reports are generated inside RankPilot and downloaded by the merchant.
- Archive and retention policies for old audits and logs should be set operationally for long-running deployments. Demo workspaces are not automatically purged in this release.

## Live acceptance steps

1. Install on a Shopify development store with a disposable product.
2. Complete OAuth; reopen the app embedded in Admin and confirm session-token authentication.
3. Run a full catalogue import and verify scopes, pagination and permission errors.
4. Apply/rollback title, snippet, description, image alt, filename, FAQ and URL changes on the disposable product.
5. Confirm redirect resolution and inspect an edited-since-preview conflict.
6. Enable the extension, set the app namespace and inspect visible FAQs. Validate with the actual theme and Judge.me active, including delayed review scripts.
7. Refresh each configured provider; inspect period boundaries and source figures.
8. Test new-product webhooks, replay a delivery, stop/restart the worker and inspect retries.
9. Enable only the desired live Autopilot features after reviewing sample output.

These live checks were not performed against Van Life Emporium during this build.
