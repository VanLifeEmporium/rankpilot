# RankPilot: credentials and approvals

Do not paste secrets into a chat. Enter them in RankPilot Settings on your deployed HTTPS instance, or configure server environment variables as described below. Demo mode deliberately rejects real API credentials.

## Shopify

1. Sign in to the [Shopify Dev Dashboard](https://dev.shopify.com/dashboard). Create a developer organisation if needed. A Shopify Partner/developer account is separate from permission to install an app in a particular store.
2. Create an app named **RankPilot**. Choose **custom distribution** for Van Life Emporium. This is a Dev Dashboard app with embedded UI, OAuth and an extension; a store-admin API-only custom app is not the same installation model.
3. Obtain the Client ID and Client secret. Set `SHOPIFY_API_KEY` and `SHOPIFY_API_SECRET` in the server's secret manager.
4. Set `SHOPIFY_APP_URL` to the deployed HTTPS URL. Register `/auth/callback` at that origin as an allowed redirect. The official Shopify React Router library manages installation, session-token validation and offline token refresh.
5. Install the project-local Shopify CLI with `npm install --save-dev @shopify/cli`. Use `npx shopify` for the CLI commands below. Link this source project using `shopify app config link --client-id YOUR_CLIENT_ID`. Preserve the scopes, metafield definitions and webhook subscriptions in the supplied TOML. Set its application URL and redirect URL to the real host.
6. Run `shopify app config validate --json`, then `shopify app deploy`. These commands require Shopify account authentication. CLI deployment publishes app configuration and the theme extension; it does **not** host the Node server.
7. Generate the custom-distribution installation link and install on the store's permanent `*.myshopify.com` domain. The store owner or an authorised staff account must approve the requested scopes.
8. In Online Store → Themes → Customise → App embeds, enable **RankPilot schema**. After applying the first FAQ, run an audit and copy the namespace shown in RankPilot Settings into the embed's namespace field. The namespace is app-specific, so it is not hard-coded into the extension.
9. Enable the vendor-as-brand option only if Shopify vendor values are genuine product brands for every item; dropshipping supplier names must not be passed off as manufacturers. Leave shipping/returns schema disabled until every entered value has been checked against actual supplier and store policies. Global values must apply to every product; otherwise keep them off and retain existing merchant-feed/theme data.

Scopes used: product/content/file reads and writes, URL redirects, and read-only legal policies. The app does not request order, customer, inventory or checkout access. Its update gateway also rejects price, inventory, vendor, supplier tags/mappings and publication-status changes. `write_products` is broad on Shopify's side; the application's explicit allowlist supplies the narrower write boundary.

Metafield definition: `[product.metafields.app.faqs]` in `shopify.app.toml`. Deploy this definition before values are written. `metafieldsSet` writes the app-owned key with the default `$app` namespace; product queries retrieve `jsonValue` and the expanded namespace used by Liquid.

Official references:
- https://shopify.dev/docs/apps/build/authentication-authorization
- https://shopify.dev/docs/apps/launch/distribution
- https://shopify.dev/docs/apps/build/online-store/theme-app-extensions

## Server and database

Use Node 22.17+ or Node 24, an HTTPS host, a persistent writable disk and a continuously running worker. This package uses SQLite for a single-store/single-host deployment. Mount the same local disk into the web and worker processes. Do not deploy the SQLite file onto ephemeral serverless storage or share it over a network filesystem.

Generate separate secrets:

```sh
node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
```

Run twice: use one output as `ENCRYPTION_KEY` and the other as `SESSION_SECRET`. The encryption key must remain stable across deployments; losing it makes stored OAuth tokens and provider keys unreadable. Protect and back up the key separately from the database. Database backups and both processes must use the same key.

Set `DEMO_MODE=false`. Configure the API keys, app URL, database URL and scopes in `.env.example`. Use `npm run setup`, `npm run build`, and `npm run start:all`. A Dockerfile and Compose configuration are supplied. For larger multi-instance deployment, migrate the Prisma datasource and migrations to PostgreSQL and use a dedicated queue; this SQLite deployment is intentionally a single-host service.

## Google Search Console and GA4

A service account is the simplest supported route for this one-store application:

1. Create a [Google Cloud project](https://console.cloud.google.com/).
2. Enable **Google Search Console API** and **Google Analytics Data API**.
3. Create a service account under IAM & Admin → Service Accounts. Create a JSON key and store it securely.
4. In Search Console, add that service account's email to the verified `vanlifeemporium.com` property with permission to read performance data. RankPilot defaults to `sc-domain:vanlifeemporium.com`; use the exact URL-prefix property identifier if that is what your account owns.
5. In GA4 Admin → Property access management, add the service account as a Viewer. Enter the numeric GA4 property ID in RankPilot. A `G-…` measurement ID is not the property ID.
6. In RankPilot's credential update form, save `googleServiceAccount` as a JSON-encoded string containing the service account document. You can create the update JSON locally with the helper below.

```sh
node scripts/google-credential.mjs /absolute/path/service-account.json
```

The helper writes `google-credential-update.json` locally, with private file permissions. Paste its content into the live app's credential form and delete the temporary file afterwards. Do not include it in Git or send it to others.

An existing OAuth setup is also supported through `googleClientId`, `googleClientSecret` and `googleRefreshToken`. Obtain offline consent with the read-only Search Console and Analytics scopes. The app refreshes the access token server-side. Never use a short-lived access token as the refresh token.

References:
- https://developers.google.com/webmaster-tools/v1/how-tos/authorizing
- https://developers.google.com/analytics/devguides/reporting/data/v1/quickstart

## Google Merchant Center

1. Enable **Merchant API** in the same Cloud project.
2. Add the service account email to the correct Merchant Center account with appropriate account access. Enter the numeric Merchant Center account ID in RankPilot.
3. Complete Merchant API developer registration, linking the Cloud project and developer contact to Merchant Center. This is a provider requirement and must be completed by the account owner/developer.
4. RankPilot reads `products/v1/accounts/{account}/products`. It does not create a second feed or modify prices, stock, identifiers or shipping settings.
5. Per-product shipping can be absent when account-level shipping applies. Review this flag in context. A product without a manufacturer-assigned GTIN must not receive an invented identifier.

References:
- https://developers.google.com/merchant/api/guides/quickstart/authentication
- https://developers.google.com/merchant/api/guides/authorization/access-your-account
- https://developers.google.com/merchant/api/guides/quickstart/developer-registration

## Bing Webmaster Tools

1. Sign in to [Bing Webmaster Tools](https://www.bing.com/webmasters/) and verify the store property (or import your verified Search Console property).
2. Under Settings → API Access, obtain an API key for the account.
3. Save it as `bingKey` in RankPilot. The adapter requests page statistics for the store URL.
4. Availability and history depend on the property and Bing API access. A failed call is logged; it is not converted into zero traffic.

Reference: https://www.bing.com/webmasters/help/webmaster-api-8cb8bbed

## PageSpeed Insights

1. Enable the **PageSpeed Insights API** in Google Cloud.
2. Create an API key, restrict it to that API and apply suitable server/IP restrictions where your host supports them.
3. Save it as `pagespeedKey`. Use Reports → Mobile template performance to test a store URL.
4. Lighthouse lab scores are not field Core Web Vitals. The response retains field data when Google has enough real-world samples.

Reference: https://developers.google.com/speed/docs/insights/v5/get-started

## AI answer-engine sampling

| Provider | Credential | Obtain access | What RankPilot records |
|---|---|---|---|
| OpenAI | `openaiKey`, optional `openaiModel` | Create a project API key and enable billing at https://platform.openai.com/ | Responses API with web search, UK location; answer text and citation URLs. Default model `gpt-5-mini`, configurable. |
| Perplexity | `perplexityKey`, optional `perplexityModel` | Create a key and add API billing at https://www.perplexity.ai/api-platform | Sonar web-grounded answers and citations. Default `sonar`, configurable. |
| Gemini | `geminiKey`, optional `geminiModel` | Create a key in https://aistudio.google.com/apikey and enable the relevant project billing/quotas | Google Search-grounded responses and grounding URLs. Default `gemini-2.5-flash`, configurable. |
| Google AI Overviews | No direct tracker credential in this package | Record the actual consumer result manually in AEO | Separate manual observation with prompt, answer, citations and date. |
| Microsoft Copilot | No direct tracker credential in this package | Record the actual consumer result manually in AEO | Separate manual observation; Bing traffic is not treated as Copilot visibility. |

Each visibility run makes up to **18 requests**: six prompts × three configured providers. Confirm provider pricing and quotas before enabling weekly runs. Account subscriptions to ChatGPT, Gemini or Perplexity do not necessarily include API usage. Model availability changes; use a model supported by the account and selected endpoint.

These are controlled samples, not universal rankings or a promise of inclusion in AI answers. Grounded Gemini responses do not measure Google AI Overviews, and OpenAI API results do not exactly reproduce ChatGPT. Competitor-domain detection uses cited URLs, not guessed brand attribution. Failed samples are excluded from the mention denominator.

References:
- https://developers.openai.com/api/docs/guides/tools-web-search
- https://docs.perplexity.ai/docs/sonar/quickstart
- https://ai.google.dev/gemini-api/docs/google-search

## Existing theme schema, Judge.me and crawler controls

The app embed detects existing JSON-LD types in the DOM and does not add a competing Product, FAQPage or other matching type. It also watches for JSON-LD inserted after initial page load. Genuine Judge.me review markup remains owned by Judge.me. RankPilot does not fetch or generate reviews, ratings, or review counts. If Judge.me has not exposed the genuine review schema, configure Judge.me directly; the current app does not provide a separate Judge.me API ingestion adapter.

The embed emits new JSON-LD after JavaScript runs. Crawlers that do not execute JavaScript rely on the theme's existing server-rendered schema. It does not rewrite or enrich existing Product entities; gaps in those entities are reported for their current owner to fix. Do not switch off correct Judge.me/theme schema merely to add the RankPilot node. Validate a live product in Google's Rich Results Test before treating structured data as ready.

Shopify currently manages `/llms.txt` through its agent-discovery documents. RankPilot audits the file and generates a fresh downloadable store summary. An app embed cannot serve or replace root `/llms.txt` or `/robots.txt`. Respecting your no-theme-code-edits requirement, RankPilot makes no automatic theme-template changes. Custom root-file changes require a separately reviewed theme update. `llms.txt` is not a ranking guarantee.

- https://shopify.dev/docs/storefronts/themes/architecture/templates/llms-txt-liquid
- https://shopify.dev/docs/storefronts/themes/seo/robots-txt

## Approvals still needed

- Shopify developer organisation, app credentials, account authentication for CLI linking/deployment, and store installation approval.
- An HTTPS host and persistent database volume for the Node application and worker.
- Merchant activation and review of the theme app embed.
- Provider account access, API billing/quota approval and Google/Bing property permissions.
- Confirmation of missing supplier facts and any global delivery/returns wording.
- Explicit authorisation if you want the remaining online Shopify UI/Liquid validation to upload source code. Automatic approval review blocked that source disclosure during this build; local checks remain available.

No live Van Life Emporium product, price, inventory, supplier mapping, theme or checkout setting was changed during development.
