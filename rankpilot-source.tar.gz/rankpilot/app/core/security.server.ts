import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { PrismaSessionStorage } from "@shopify/shopify-app-session-storage-prisma";
import type { Session } from "@shopify/shopify-api";
import prisma from "../db.server";
function key() {
  const raw = process.env.ENCRYPTION_KEY;
  if (!raw || !/^[a-f0-9]{64}$/i.test(raw))
    throw new Error(
      "ENCRYPTION_KEY must be 32 random bytes encoded as 64 hex characters",
    );
  return Buffer.from(raw, "hex");
}
export function encrypt(value: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key(), iv);
  const body = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  return [
    "v1",
    iv.toString("base64"),
    cipher.getAuthTag().toString("base64"),
    body.toString("base64"),
  ].join(".");
}
export function decrypt(value: string) {
  const [version, iv, tag, body] = value.split(".");
  if (version !== "v1") throw new Error("Refusing unencrypted credential");
  const cipher = createDecipheriv(
    "aes-256-gcm",
    key(),
    Buffer.from(iv, "base64"),
  );
  cipher.setAuthTag(Buffer.from(tag, "base64"));
  return Buffer.concat([
    cipher.update(Buffer.from(body, "base64")),
    cipher.final(),
  ]).toString("utf8");
}
export class EncryptedSessionStorage extends PrismaSessionStorage<
  typeof prisma
> {
  async storeSession(session: Session) {
    const access = session.accessToken;
    const refresh = session.refreshToken;
    try {
      if (access) session.accessToken = encrypt(access);
      if (refresh) session.refreshToken = encrypt(refresh);
      return await super.storeSession(session);
    } finally {
      session.accessToken = access;
      session.refreshToken = refresh;
    }
  }
  async loadSession(id: string) {
    const session = await super.loadSession(id);
    if (session?.accessToken)
      session.accessToken = decrypt(session.accessToken);
    if (session?.refreshToken)
      session.refreshToken = decrypt(session.refreshToken);
    return session;
  }
  async findSessionsByShop(shop: string) {
    const sessions = await super.findSessionsByShop(shop);
    return sessions.map((s) => {
      if (s.accessToken) s.accessToken = decrypt(s.accessToken);
      if (s.refreshToken) s.refreshToken = decrypt(s.refreshToken);
      return s;
    });
  }
}
export const encryptedSessionStorage = new EncryptedSessionStorage(prisma);
export function requireSameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  const expected = new URL(process.env.SHOPIFY_APP_URL || request.url).origin;
  if (!origin || origin !== expected)
    throw new Response("Invalid request origin", { status: 403 });
}
export async function credentials(
  storeId: string,
): Promise<Record<string, string>> {
  const s = await prisma.store.findUniqueOrThrow({ where: { id: storeId } });
  return s.credentials === "{}" ? {} : JSON.parse(decrypt(s.credentials));
}
