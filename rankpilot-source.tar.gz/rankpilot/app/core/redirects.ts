type Mapping = {path:string;target:string};
export function redirectAction(existing:Mapping|null,expected:Mapping|null,desired:Mapping|null) {
  if(existing?.target === desired?.target && Boolean(existing) === Boolean(desired)) return 'none';
  if((existing?.target || null) !== (expected?.target || null)) throw new Error('Conflict: redirect destination has been changed');
  return !desired ? 'delete' : existing ? 'update' : 'create';
}
