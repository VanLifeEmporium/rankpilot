import { createHash, randomUUID } from "node:crypto";
import prisma from "../db.server";
import {
  auditCatalogue,
  extractFacts,
  keywordFor,
  optimise,
  topics,
  text,
} from "./catalogue";
import {
  type Payload,
  type Feature,
  type Facts,
  settings,
  escapeHtml,
  slug,
} from "./types";
import {
  allNodes,
  hydrateProduct,
  normalise,
  graphql,
  operations,
  fetchResource,
  updateResource,
  type GraphQL,
} from "./shopify-api.server";
import { crawlStore } from "./crawl.server";
import { metricPair } from "./analytics";
import {
  collectAnalytics,
  trackVisibility,
  pageSpeed,
} from "./integrations.server";
export const log = (storeId: string, message: string, detail: unknown = {}) =>
  prisma.event.create({
    data: { storeId, message, detail: JSON.stringify(detail) },
  });
export async function enqueue(
  storeId: string,
  kind: string,
  payload: unknown = {},
  dedup: string = randomUUID(),
) {
  return prisma.job.upsert({
    where: { dedup: `${storeId}:${kind}:${dedup}` },
    create: {
      storeId,
      kind,
      payload: JSON.stringify(payload),
      dedup: `${storeId}:${kind}:${dedup}`,
    },
    update: {},
  });
}
export async function clientFor(storeId: string): Promise<GraphQL | null> {
  const store = await prisma.store.findUniqueOrThrow({
    where: { id: storeId },
  });
  if (!store.active) throw new Error("Store is uninstalled");
  if (store.demo) return null;
  const { unauthenticated } = await import("../shopify.server");
  const { admin } = await unauthenticated.admin(storeId);
  return admin.graphql as GraphQL;
}
export function fieldValue(p: Payload, feature: string): any {
  switch (feature) {
    case "title":
      return p.title;
    case "seo":
      return p.seo;
    case "handle":
      return p.handle;
    case "description":
    case "links":
      return p.descriptionHtml;
    case "faq":
      return p.faqs || [];
    case "alt":
      return p.images.map(({ id, alt }) => ({ id, alt }));
    case "filename":
      return p.images.map(({ id, filename }) => ({ id, filename }));
    default:
      throw new Error("Unknown feature");
  }
}
export function withField(p: Payload, feature: string, value: any): Payload {
  const next = structuredClone(p);
  if (feature === "description" || feature === "links")
    next.descriptionHtml = value;
  else if (feature === "faq") next.faqs = value;
  else if (feature === "alt" || feature === "filename")
    next.images = next.images.map((i) => ({
      ...i,
      ...value.find((v: any) => v.id === i.id),
    }));
  else (next as any)[feature] = value;
  return next;
}
export async function sync(storeId: string, productId?: string) {
  const client = await clientFor(storeId);
  if (!client) return;
  if (!productId) {
    const d = await graphql(client, operations.shop);
    if (d.shop.currencyCode !== "GBP")
      throw new Error(
        "RankPilot is configured for GBP. Check the store before proceeding.",
      );
    const s = await prisma.store.findUniqueOrThrow({ where: { id: storeId } });
    const discovery = JSON.parse(s.discoveries);
    await prisma.store.update({
      where: { id: storeId },
      data: {
        domain: d.shop.primaryDomain.url,
        discoveries: JSON.stringify({
          ...discovery,
          shop: d.shop,
          blogs: d.blogs.nodes,
        }),
      },
    });
  }
  const kinds = productId
    ? ["products"]
    : ["products", "collections", "pages", "articles"];
  for (const plural of kinds) {
    const kind =
      plural.slice(0, -1) === "categorie" ? "category" : plural.slice(0, -1);
    if (productId) {
      const p = await fetchResource(client, productId, "product");
      await saveResource(storeId, productId, "product", p);
      continue;
    }
    const nodes = await allNodes(client, plural as any);
    for (const node of nodes) {
      if (kind === "product") await hydrateProduct(client, node);
      await saveResource(storeId, node.id, kind, normalise(node, kind));
    }
    await prisma.resource.deleteMany({
      where: { storeId, kind, remoteId: { notIn: nodes.map((n) => n.id) } },
    });
  }
  await log(storeId, "Catalogue synchronised", {
    scope: productId || "all resources",
  });
}
async function saveResource(
  storeId: string,
  remoteId: string,
  kind: string,
  p: Payload,
) {
  const existing = await prisma.resource.findUnique({
    where: { storeId_remoteId: { storeId, remoteId } },
  });
  const changed =
    existing &&
    JSON.stringify(JSON.parse(existing.payload)) !== JSON.stringify(p);
  let facts: Facts = existing ? JSON.parse(existing.facts) : extractFacts(p);
  // Supplier updates invalidate confirmation, except when the new field matches an app-applied change.
  if (
    changed &&
    JSON.parse(existing!.payload).descriptionHtml !== p.descriptionHtml
  ) {
    const applied = await prisma.change.findFirst({
      where: {
        storeId,
        resourceId: existing!.id,
        feature: { in: ["description", "links"] },
        status: "applied",
      },
      orderBy: { appliedAt: "desc" },
    });
    if (!applied || JSON.parse(applied.after) !== p.descriptionHtml)
      facts = Object.fromEntries(
        Object.entries(facts).map(([k, v]) => [k, { ...v, confirmed: false }]),
      );
  }
  return prisma.resource.upsert({
    where: { storeId_remoteId: { storeId, remoteId } },
    create: {
      storeId,
      remoteId,
      kind,
      title: p.title,
      handle: p.handle,
      collection: p.collections[0] || "",
      payload: JSON.stringify(p),
      facts: JSON.stringify(facts),
      keyword: keywordFor(p, kind),
    },
    update: {
      title: p.title,
      handle: p.handle,
      collection: p.collections[0] || "",
      payload: JSON.stringify(p),
      facts: JSON.stringify(facts),
    },
  });
}
export async function audit(storeId: string) {
  const store = await prisma.store.findUniqueOrThrow({
    where: { id: storeId },
  });
  const resources = await prisma.resource.findMany({
    where: {
      storeId,
      kind: { in: ["product", "collection", "page", "article"] },
    },
  });
  const result = auditCatalogue(resources);
  let coverage: any = {
    catalogue: resources.length,
    storefront: 0,
    externalLinks: "Not scanned",
    supplierCopy: "Heuristic only",
    score: "Catalogue checks only; not a search-engine ranking score",
    aeoScore: "Percentage of four core product facts confirmed",
  };
  if (!store.demo) {
    const crawl = await crawlStore(
      store.domain,
      resources,
      settings(store.settings).crawlLimit,
    );
    result.issues.push(...crawl.issues);
    await prisma.store.update({
      where: { id: storeId },
      data: {
        discoveries: JSON.stringify({
          ...JSON.parse(store.discoveries),
          ...crawl.discoveries,
        }),
      },
    });
    coverage = {
      ...coverage,
      storefront: crawl.discoveries.scanned,
      crawlLimit: settings(store.settings).crawlLimit,
      errors: crawl.discoveries.errors,
    };
  } else
    coverage.demo =
      "Sample data. Live HTML, links, schema and template performance are not assessed.";
  const row = await prisma.audit.create({
    data: {
      storeId,
      score: result.score,
      aeoScore: result.aeoScore,
      resourceCount: resources.length,
      issues: JSON.stringify(result.issues),
      coverage: JSON.stringify(coverage),
    },
  });
  await log(storeId, "Audit completed", {
    score: result.score,
    issues: result.issues.length,
  });
  return row;
}
export async function propose(
  storeId: string,
  resourceId: string,
  feature: Feature,
) {
  const resource = await prisma.resource.findFirstOrThrow({
    where: { id: resourceId, storeId },
  });
  const store = await prisma.store.findUniqueOrThrow({
    where: { id: storeId },
  });
  const cfg = settings(store.settings);
  const p: Payload = JSON.parse(resource.payload);
  if (
    ["alt", "filename", "faq"].includes(feature) &&
    resource.kind !== "product"
  )
    throw new Error("This feature currently applies to product resources");
  const related = await prisma.resource.findMany({
    where: {
      storeId,
      collection: resource.collection,
      id: { not: resource.id },
      kind: { in: ["product", "collection"] },
    },
    take: 3,
  });
  const proposal = optimise(
    p,
    resource.kind,
    feature,
    JSON.parse(resource.facts),
    resource.keyword,
    cfg,
    related.map((r) => ({ title: r.title, url: `/${r.kind}s/${r.handle}` })),
  );
  if (proposal.blockers.length && JSON.stringify(proposal.before) === JSON.stringify(proposal.after))
    throw new Error(proposal.blockers.join(" "));
  if (JSON.stringify(proposal.before) === JSON.stringify(proposal.after))
    return null;
  const pending = await prisma.change.findFirst({
    where: {
      storeId,
      resourceId,
      feature,
      status: { in: ["pending", "approved", "applying"] },
    },
  });
  if (pending) return pending;
  const row = await prisma.change.create({
    data: {
      storeId,
      resourceId,
      feature,
      before: JSON.stringify(proposal.before),
      after: JSON.stringify(proposal.after),
      blockers: JSON.stringify(proposal.blockers),
      reasons: JSON.stringify(proposal.reasons),
    },
  });
  if (cfg.autopilot[feature] && !proposal.blockers.length) {
    await approve(storeId, row.id, "Autopilot");
  }
  return row;
}
export function assertSafeCopy(feature: string, before: any, after: any) {
  if (feature === "description")
    throw new Error("Description replacement is paused. Existing content is protected; reject this proposal.");
  if (feature === "seo" && ["title", "description"].some(key =>
    String(before?.[key] || "").trim() && before[key] !== after?.[key]))
    throw new Error("This proposal replaces existing metadata. Reject it and regenerate using the content safeguards.");
}
export async function approve(storeId: string, id: string, actor: string) {
  const row = await prisma.change.findFirstOrThrow({ where: { id, storeId } });
  assertSafeCopy(row.feature, JSON.parse(row.before), JSON.parse(row.after));
  if (row.status !== "pending")
    throw new Error("This change is no longer awaiting approval");
  if (JSON.parse(row.blockers).length)
    throw new Error("Resolve missing facts and regenerate this preview first");
  await prisma.$transaction(async (tx) => {
    const claimed = await tx.change.updateMany({
      where: { id, storeId, status: "pending" },
      data: { status: "approved", approvedBy: actor },
    });
    if (!claimed.count) throw new Error("Change already reviewed");
    await tx.job.create({
      data: {
        storeId,
        kind: "apply",
        payload: JSON.stringify({ changeId: id }),
        dedup: `${storeId}:apply:${id}`,
      },
    });
  });
  await log(storeId, "Change approved", { changeId: id, actor });
}
export function compatibleState(
  actual: any,
  before: any,
  after: any,
  feature: string,
) {
  if (feature === "alt" || feature === "filename")
    return (
      Array.isArray(actual) &&
      actual.length === before.length &&
      actual.every((item: any) =>
        [
          before.find((v: any) => v.id === item.id),
          after.find((v: any) => v.id === item.id),
        ].some((v) => JSON.stringify(v) === JSON.stringify(item)),
      )
    );
  return (
    JSON.stringify(actual) === JSON.stringify(before) ||
    JSON.stringify(actual) === JSON.stringify(after)
  );
}
export async function applyChange(
  storeId: string,
  id: string,
  rollback = false,
) {
  const change = await prisma.change.findFirstOrThrow({
    where: { id, storeId },
  });
  if (
    rollback &&
    change.status !== "applied" &&
    change.status !== "rolling_back"
  )
    throw new Error("Only applied changes can be rolled back");
  if (!rollback && !["approved", "applying"].includes(change.status)) return;
  if (change.feature === "redirect")
    return applyRedirect(storeId, change, rollback);
  if (change.feature === "draft")
    return rollbackDraft(storeId, change, rollback);
  const r = await prisma.resource.findFirstOrThrow({
    where: { id: change.resourceId, storeId },
  });
  const client = await clientFor(storeId);
  const p = client
    ? await fetchResource(client, r.remoteId, r.kind)
    : JSON.parse(r.payload);
  const before = JSON.parse(rollback ? change.after : change.before),
    after = JSON.parse(rollback ? change.before : change.after);
  if (!rollback) assertSafeCopy(change.feature, before, after);
  const actual = fieldValue(p, change.feature);
  if (!compatibleState(actual, before, after, change.feature)) {
    await prisma.change.update({
      where: { id },
      data: {
        status: rollback ? "applied" : "conflict",
        error:
          "The resource changed after this preview. Refresh and review again.",
      },
    });
    throw new Error("Conflict: refusing to overwrite newer edits");
  }
  await prisma.change.update({
    where: { id },
    data: { status: rollback ? "rolling_back" : "applying", error: null },
  });
  if (JSON.stringify(actual) !== JSON.stringify(after) && client) {
    // Shopify may already have a redirect at the destination of a rollback. Remove only an exact app-created inverse.
    if (change.feature === "handle" && rollback) {
      const path = `/${r.kind === "article" ? `blogs/${p.blogHandle}` : r.kind + "s"}/${after}`;
      const redirects = await graphql(client, operations.redirectLookup, {
        query: `path:${path}`,
      });
      for (const redirect of redirects.urlRedirects.nodes) {
        if (
          redirect.path === path &&
          redirect.target ===
            `/${r.kind === "article" ? `blogs/${p.blogHandle}` : r.kind + "s"}/${before}`
        )
          await graphql(client, operations.redirectDelete, { id: redirect.id });
      }
    }
    await updateResource(client, r.remoteId, r.kind, change.feature, after);
  }
  const next = withField(p, change.feature, after);
  await prisma.$transaction([
    prisma.resource.update({
      where: { id: r.id },
      data: {
        payload: JSON.stringify(next),
        title: next.title,
        handle: next.handle,
      },
    }),
    prisma.change.update({
      where: { id },
      data: {
        status: rollback ? "rolled_back" : "applied",
        appliedAt: rollback ? change.appliedAt : new Date(),
        error: null,
      },
    }),
  ]);
  await log(storeId, rollback ? "Change rolled back" : "Change applied", {
    changeId: id,
    feature: change.feature,
    title: r.title,
    demo: !client,
  });
}
export async function createDraft(
  storeId: string,
  title: string,
  jobId: string,
) {
  if (!topics.includes(title)) throw new Error("Select a content-plan topic");
  const store = await prisma.store.findUniqueOrThrow({
    where: { id: storeId },
  });
  const products = await prisma.resource.findMany({
    where: { storeId, kind: "product" },
    take: 50,
  });
  const relevant = products
    .filter((p) => {
      const words = title.toLowerCase();
      return words.includes("power")
        ? p.collection === "Off Grid"
        : words.includes("kitchen")
          ? p.collection === "Kitchen/Cooking"
          : words.includes("gifts")
            ? p.collection === "Signature"
            : p.collection === "Interiors";
    })
    .slice(0, 4);
  const sections = relevant
    .map((r) => {
      const p: Payload = JSON.parse(r.payload);
      const facts: Facts = JSON.parse(r.facts);
      return `<h2>${escapeHtml(p.title)}</h2><p><a href="/products/${escapeHtml(p.handle)}">View the product and current details</a></p><ul>${Object.entries(
        facts,
      )
        .filter(([, f]) => f.confirmed)
        .map(([k, f]) => `<li>${escapeHtml(k)}: ${escapeHtml(f.value)}</li>`)
        .join("")}</ul>`;
    })
    .join("");
  const body = `<p><strong>Quick answer:</strong> Start with the space you have, how you travel and the equipment you already own. Compare dimensions and, where relevant, power requirements before choosing additional kit.</p><h2>Start with your own setup</h2><p>Make a short list of what you need the product to do. Measure where it will be stored and used. Keep access routes clear and check the manufacturer's instructions for installation, ventilation and care.</p><h2>Compare the details that matter</h2><p>Look beyond the product name. Check the materials, dimensions, weight and what is included. For electrical equipment, confirm the input and output requirements and compatibility with your system.</p>${sections}<h2>Before you choose</h2><p>Review delivery and returns information on the store. Ask about any missing specifications before ordering.</p><h2>Editorial review required</h2><p>This draft has not tested or ranked these products. Confirm suitability and all product facts before publication. Add primary sources for any claims about real places, regulations, campsites or safety guidance.</p><h2>Sources</h2><ul>${relevant.map((r) => `<li><a href="/products/${escapeHtml(r.handle)}">${escapeHtml(r.title)}</a> — catalogue facts, manual verification required</li>`).join("")}</ul>`;
  const client = await clientFor(storeId);
  const draftHandle = slug(title) + "-" + jobId.slice(-6);
  let remoteId = `draft-${jobId}`;
  const cfg = settings(store.settings);
  if (client) {
    if (!cfg.blogId) throw new Error("Choose a Shopify blog ID in Settings");
    const existing = await graphql(client, operations.draftLookup, {
      query: `handle:${draftHandle}`,
    });
    const match = existing.articles.nodes.find(
      (a: any) => a.handle === draftHandle,
    );
    if (match) {
      if (match.body !== body || match.title !== title || match.isPublished)
        throw new Error("Conflict: the recovered draft has been edited");
      remoteId = match.id;
    } else {
      const d = await graphql(client, operations.draft, {
        article: {
          blogId: cfg.blogId,
          handle: draftHandle,
          title,
          body,
          isPublished: false,
          author: { name: "Van Life Emporium" },
          tags: ["RankPilot draft", "Manual verification required"],
        },
      });
      remoteId = d.articleCreate.article.id;
    }
  }
  const payload: Payload = {
    title,
    handle: draftHandle,
    descriptionHtml: body,
    seo: { title, description: "" },
    images: [],
    collections: [],
    published: false,
    blogId: cfg.blogId,
  };
  const resource = await saveResource(storeId, remoteId, "article", payload);
  if (
    !(await prisma.change.findFirst({
      where: { storeId, resourceId: resource.id, feature: "draft" },
    }))
  )
    await prisma.change.create({
      data: {
        storeId,
        resourceId: resource.id,
        feature: "draft",
        before: "null",
        after: JSON.stringify(payload),
        status: "applied",
        approvedBy: "Requested draft creation",
        appliedAt: new Date(),
        reasons: JSON.stringify([
          "Saved as an unpublished article. Rollback deletes this draft only if nobody has edited or published it.",
        ]),
      },
    });
  await log(storeId, "Article saved as an unpublished draft", {
    title,
    remoteId,
  });
}
export function llmsText(
  domain: string,
  resources: { kind: string; title: string; handle: string }[],
  config: ReturnType<typeof settings>,
) {
  return `# Van Life Emporium\n\n> Home is the road. Campervan, motorhome and outdoor products for shoppers in the UK.\n\n## Collections\n${resources
    .filter((r) => r.kind === "collection")
    .map((r) => `- [${r.title}](${domain}/collections/${r.handle})`)
    .join(
      "\n",
    )}\n\n## Signature\nThe brand's own wood print line, produced to order. Refer to individual product pages for verified specifications.\n\n## Delivery and returns\n${config.policies.delivery || "Delivery times have not been confirmed in RankPilot. Consult the store policy."}\n${config.policies.returns || "Consult the current returns policy before ordering."}\n${config.policies.source ? `Policy source: ${config.policies.source}` : ""}\n\nPrices and availability change. Read the live product page.\n`;
}
export async function weeklyReport(storeId: string) {
  const since = new Date(Date.now() - 7 * 86400000);
  const changes = await prisma.change.findMany({
    where: { storeId, appliedAt: { gte: since } },
  });
  const audits = await prisma.audit.findMany({
    where: { storeId },
    orderBy: { createdAt: "desc" },
    take: 2,
  });
  const observations = await prisma.observation.findMany({
    where: { storeId, createdAt: { gte: since } },
  });
  const metrics = await prisma.metric.findMany({ where: { storeId } });
  const markdown = `# RankPilot weekly report\n\nWeek ending ${new Date().toLocaleDateString("en-GB")}\n\n## Changes\n${changes.length} approved changes applied.\n${changes.map((c) => `- ${c.feature}: ${c.status} (${c.id})`).join("\n")}\n\n## Visibility\nCatalogue SEO score: ${audits[0]?.score ?? "Not audited"}. Previous: ${audits[1]?.score ?? "No baseline"}.\nAI mention rate: ${observations.length ? Math.round((observations.filter((o) => o.mentioned).length / observations.length) * 100) + "% of " + observations.length + " samples" : "No observations"}. API samples are not consumer search rankings.\nAnalytics snapshots: ${metrics.length}. Changes in traffic do not establish causation.\n\n## Next priorities\n${
    audits[0]
      ? JSON.parse(audits[0].issues)
          .slice(0, 10)
          .map((i: any) => `- ${i.title}: ${i.detail}`)
          .join("\n")
      : "Run the first audit."
  }\n`;
  return prisma.report.create({ data: { storeId, markdown } });
}
export async function requeueUnderperformers(storeId: string) {
  const store = await prisma.store.findUniqueOrThrow({
    where: { id: storeId },
  });
  if (!settings(store.settings).requeue) return;
  const snapshots = await prisma.metric.findMany({
    where: { storeId, provider: "gsc" },
    orderBy: { period: "desc" },
  });
  const pair = metricPair(snapshots, "gsc");
  if (pair.length < 2) return;
  const totals = (s: string) => {
    const map = new Map<string, { clicks: number; impressions: number }>();
    for (const row of JSON.parse(s).rows || []) {
      const p = row.keys[0];
      const v = map.get(p) || { clicks: 0, impressions: 0 };
      v.clicks += row.clicks;
      v.impressions += row.impressions;
      map.set(p, v);
    }
    return map;
  };
  const current = totals(JSON.stringify(pair[0])),
    previous = totals(JSON.stringify(pair[1]));
  const resources = await prisma.resource.findMany({ where: { storeId } });
  for (const [url, p] of previous) {
    const c = current.get(url);
    if (
      p.impressions < 100 ||
      p.clicks < 10 ||
      !c ||
      c.clicks > p.clicks * 0.75
    )
      continue;
    const resource = resources.find((r) =>
      new URL(url).pathname.endsWith("/" + r.handle),
    );
    if (!resource) continue;
    const recent = await prisma.change.findFirst({
      where: {
        storeId,
        resourceId: resource.id,
        createdAt: { gte: new Date(Date.now() - 28 * 86400000) },
      },
    });
    if (!recent) {
      await propose(storeId, resource.id, "seo");
      await log(storeId, "Underperforming page re-queued", {
        url,
        previousClicks: p.clicks,
        currentClicks: c.clicks,
      });
    }
  }
}
export async function executeJob(job: {
  id: string;
  storeId: string;
  kind: string;
  payload: string;
}) {
  const p = JSON.parse(job.payload);
  switch (job.kind) {
    case "audit":
      await sync(job.storeId);
      return audit(job.storeId);
    case "optimise":
      for (const id of p.ids) await propose(job.storeId, id, p.feature);
      return;
    case "apply":
      return applyChange(job.storeId, p.changeId);
    case "rollback":
      return applyChange(job.storeId, p.changeId, true);
    case "webhook": {
      const before = await prisma.resource.findUnique({
        where: {
          storeId_remoteId: { storeId: job.storeId, remoteId: p.productId },
        },
      });
      await sync(job.storeId, p.productId);
      const r = await prisma.resource.findUnique({
        where: {
          storeId_remoteId: { storeId: job.storeId, remoteId: p.productId },
        },
      });
      if (r && (!before || before.payload !== r.payload)) {
        for (const f of ["seo", "description", "alt", "faq"] as Feature[])
          await propose(job.storeId, r.id, f);
      }
      return;
    }
    case "draft":
      return createDraft(job.storeId, p.title, job.id);
    case "analytics":
      await collectAnalytics(job.storeId);
      return requeueUnderperformers(job.storeId);
    case "visibility":
      return trackVisibility(job.storeId);
    case "pagespeed":
      return pageSpeed(job.storeId, p.url);
    case "report":
      return weeklyReport(job.storeId);
    default:
      throw new Error("Unknown job type");
  }
}
export async function tick() {
  const cutoff = new Date(Date.now() - 5 * 60000);
  await prisma.job.updateMany({
    where: { status: "running", lockedAt: { lt: cutoff } },
    data: { status: "queued", lockedAt: null },
  });
  const next = await prisma.job.findFirst({
    where: {
      status: "queued",
      runAt: { lte: new Date() },
      attempts: { lt: 5 },
    },
    orderBy: { createdAt: "asc" },
  });
  if (!next) return false;
  const claimed = await prisma.job.updateMany({
    where: { id: next.id, status: "queued" },
    data: {
      status: "running",
      lockedAt: new Date(),
      attempts: { increment: 1 },
    },
  });
  if (!claimed.count) return true;
  const heartbeat = setInterval(
    () =>
      void prisma.job
        .updateMany({
          where: { id: next.id, status: "running" },
          data: { lockedAt: new Date() },
        })
        .catch(() => {}),
    30000,
  );
  try {
    await executeJob(next);
    await prisma.job.update({
      where: { id: next.id },
      data: { status: "completed", lockedAt: null, error: null },
    });
  } catch (e) {
    const error = e instanceof Error ? e.message : "Job failed";
    const terminal =
      next.attempts >= 3 ||
      /Conflict|Confirm|Select|Choose|Connect|requires|No AI|Only|longer|credentials/i.test(
        error,
      );
    await prisma.job.update({
      where: { id: next.id },
      data: {
        status: terminal ? "failed" : "queued",
        lockedAt: null,
        error,
        runAt: new Date(
          Date.now() + Math.min(60000, 2000 * 2 ** next.attempts),
        ),
      },
    });
    await log(next.storeId, "Job needs attention", { kind: next.kind, error });
  } finally {
    clearInterval(heartbeat);
  }
  return true;
}
export async function schedule() {
  const stores = await prisma.store.findMany({
    where: { active: true, demo: false, nextWeekly: { lte: new Date() } },
  });
  for (const s of stores) {
    const cfg = settings(s.settings);
    if (cfg.weekly) {
      for (const kind of ["audit", "analytics", "visibility", "report"])
        await enqueue(s.id, kind, {}, `${s.nextWeekly.toISOString()}`);
    }
    await prisma.store.update({
      where: { id: s.id },
      data: { nextWeekly: new Date(Date.now() + 7 * 86400000) },
    });
  }
}

export async function proposeRedirect(
  storeId: string,
  path: string,
  target: string,
) {
  if (
    !/^\/collections\/[a-z0-9][a-z0-9-]*$/.test(path) ||
    !/^\/collections\/[a-z0-9][a-z0-9-]*$/.test(target) ||
    path === target
  )
    throw new Error(
      "Use distinct collection paths such as /collections/retired-name",
    );
  const resources = await prisma.resource.findMany({
    where: { storeId, kind: "collection" },
  });
  if (resources.some((r) => "/collections/" + r.handle === path))
    throw new Error(
      "The old collection is still present. Retire it in Shopify before adding a redirect.",
    );
  if (!resources.some((r) => "/collections/" + r.handle === target))
    throw new Error("Choose an existing collection as the destination.");
  const client = await clientFor(storeId);
  if (client) {
    const result = await graphql(client, operations.redirectLookup, {
      query: `path:${path}`,
    });
    if (result.urlRedirects.nodes.some((r: any) => r.path === path))
      throw new Error(
        "A redirect already exists at that path. Review it in Shopify.",
      );
  }
  const resource = await prisma.resource.upsert({
    where: { storeId_remoteId: { storeId, remoteId: "redirect:" + path } },
    create: {
      storeId,
      remoteId: "redirect:" + path,
      kind: "redirect",
      title: path,
      handle: path,
      payload: JSON.stringify({ path, target }),
    },
    update: {},
  });
  const pending = await prisma.change.findFirst({
    where: {
      storeId,
      resourceId: resource.id,
      feature: "redirect",
      status: { in: ["pending", "approved", "applying"] },
    },
  });
  if (pending) return pending;
  return prisma.change.create({
    data: {
      storeId,
      resourceId: resource.id,
      feature: "redirect",
      before: "null",
      after: JSON.stringify({ path, target }),
      reasons: JSON.stringify([
        "Redirect a retired collection to an existing relevant collection. Rollback removes only this exact mapping.",
      ]),
    },
  });
}
async function applyRedirect(storeId: string, change: any, rollback: boolean) {
  const mapping = JSON.parse(change.after);
  const client = await clientFor(storeId);
  await prisma.change.update({
    where: { id: change.id },
    data: { status: rollback ? "rolling_back" : "applying" },
  });
  if (client) {
    const result = await graphql(client, operations.redirectLookup, {
      query: `path:${mapping.path}`,
    });
    const existing = result.urlRedirects.nodes.find(
      (r: any) => r.path === mapping.path,
    );
    if (existing && existing.target !== mapping.target)
      throw new Error("Conflict: redirect destination has been changed");
    if (rollback) {
      if (existing)
        await graphql(client, operations.redirectDelete, { id: existing.id });
    } else if (!existing)
      await graphql(client, operations.redirect, { input: mapping });
  }
  await prisma.change.update({
    where: { id: change.id },
    data: {
      status: rollback ? "rolled_back" : "applied",
      appliedAt: new Date(),
      error: null,
    },
  });
  await log(
    storeId,
    rollback ? "Redirect rolled back" : "Redirect applied",
    mapping,
  );
}

async function rollbackDraft(storeId: string, change: any, rollback: boolean) {
  if (!rollback) return;
  const resource = await prisma.resource.findFirstOrThrow({
    where: { id: change.resourceId, storeId },
  });
  const original: Payload = JSON.parse(change.after);
  const client = await clientFor(storeId);
  let current: Payload | null = JSON.parse(resource.payload);
  if (client) {
    try {
      current = await fetchResource(client, resource.remoteId, "article");
    } catch (e) {
      if (e instanceof Error && e.message === "Resource no longer exists")
        current = null;
      else throw e;
    }
  }
  if (
    current &&
    (current.published ||
      current.title !== original.title ||
      current.descriptionHtml !== original.descriptionHtml ||
      current.handle !== original.handle)
  )
    throw new Error(
      "Conflict: draft has been edited or published; preserve the newer version",
    );
  if (client && current)
    await graphql(client, operations.deleteDraft, { id: resource.remoteId });
  await prisma.change.update({
    where: { id: change.id },
    data: { status: "rolled_back" },
  });
  await prisma.resource.deleteMany({ where: { id: resource.id, storeId } });
  await log(storeId, "Draft creation rolled back", { title: original.title });
}
