import prisma from "../db.server";
import { defaults, type Payload } from "./types";
import { keywordFor } from "./catalogue";
export async function seedDemo(storeId: string) {
  const examples = [
    [
      "HOT SALE Portable Power Station 500Wh",
      "Off Grid",
      "<p>100% brand new. Best quality outdoor camping power supply.</p>",
      {
        dimensions: "29 × 19 × 20 cm",
        weight: "6 kg",
        power: "500Wh capacity; 230V AC output",
        included: "Power station and mains charging cable",
        materials: "ABS housing",
      },
    ],
    [
      "Linen Blend Campervan Cushion",
      "Interiors",
      "<p>Linen blend cushion cover. Colour: oat. Concealed zip.</p>",
      {
        dimensions: "45 × 45 cm",
        weight: "180 g",
        materials: "55% linen, 45% cotton",
        included: "One cushion cover; insert not included",
        care: "Gentle wash at 30°C",
      },
    ],
    [
      "Collapsible Camping Kettle 1.2L",
      "Kitchen/Cooking",
      "<p>Space saving foldable kettle for outdoor adventure.</p>",
      {
        dimensions: "15 × 15 × 9 cm when folded",
        weight: "320 g",
        materials: "Silicone body with stainless steel base",
        included: "One kettle",
      },
    ],
    [
      "Home is the road Wood Print",
      "Signature",
      "<p>Wood print for van life.</p>",
      {
        dimensions: "30 × 40 cm",
        weight: "600 g",
        materials: "Birch plywood",
        included: "One wood print",
        care: "Wipe with a dry cloth",
      },
    ],
    [
      "Campervan Storage Pockets",
      "Interiors",
      "<p>Storage pockets. Keep your belongings organised.</p>",
      {
        dimensions: "60 × 40 cm",
        weight: "250 g",
        materials: "Cotton canvas",
        included: "One hanging organiser",
      },
    ],
    [
      "USB Reading Light",
      "Off Grid",
      "<p>Portable lamp with flexible neck and USB power.</p>",
      {
        dimensions: "35 cm overall length",
        weight: "90 g",
        power: "5V USB input, 3W",
        materials: "Aluminium and ABS",
        included: "One USB reading light",
      },
    ],
  ] as const;
  await prisma.store.upsert({
    where: { id: storeId },
    create: {
      id: storeId,
      demo: true,
      settings: JSON.stringify(defaults),
      discoveries: JSON.stringify({
        note: "Sample catalogue. No live store scan has run.",
      }),
    },
    update: {},
  });
  for (let i = 0; i < examples.length; i++) {
    const [title, collection, html, rawFacts] = examples[i];
    const payload: Payload = {
      title,
      handle: [
        "hot-sale-portable-power-station-500wh-xx",
        "linen-cushion",
        "collapsible-kettle",
        "home-is-the-road-print",
        "storage-pockets",
        "usb-reading-light",
      ][i],
      descriptionHtml: html,
      seo: { title: i === 1 ? title : "", description: "" },
      images: [
        {
          id: `demo-image-${i}`,
          url: `/products/${i}.svg`,
          alt: "",
          filename: `supplier_${i}.jpg`,
          width: i === 0 ? 4000 : 1200,
          height: 1200,
        },
      ],
      collections: [collection],
      vendor: "Demo supplier",
      productType: collection,
      variants: [
        {
          sku: `DEMO-${i}`,
          barcode: "",
          price: ["349.00", "24.00", "29.00", "45.00", "22.00", "18.00"][i],
        },
      ],
      published: true,
    };
    await prisma.resource.upsert({
      where: { storeId_remoteId: { storeId, remoteId: `demo-product-${i}` } },
      create: {
        storeId,
        remoteId: `demo-product-${i}`,
        kind: "product",
        title,
        handle: payload.handle,
        collection,
        payload: JSON.stringify(payload),
        facts: JSON.stringify(
          Object.fromEntries(
            Object.entries(rawFacts).map(([k, value]) => [
              k,
              {
                value,
                source: "Demonstration specification; not a real product claim",
                confirmed: i !== 0 || k !== "power",
              },
            ]),
          ),
        ),
        keyword: keywordFor(payload, "product"),
      },
      update: {},
    });
  }
  for (const title of [
    "Interiors",
    "Kitchen/Cooking",
    "Off Grid",
    "Best Sellers",
    "Signature",
  ]) {
    const payload: Payload = {
      title,
      handle: title.toLowerCase().replace(/[^a-z]+/g, "-"),
      descriptionHtml: "",
      seo: { title: "", description: "" },
      images: [],
      collections: [],
      published: true,
    };
    await prisma.resource.upsert({
      where: {
        storeId_remoteId: { storeId, remoteId: `demo-collection-${title}` },
      },
      create: {
        storeId,
        remoteId: `demo-collection-${title}`,
        kind: "collection",
        title,
        handle: payload.handle,
        collection: title,
        payload: JSON.stringify(payload),
        keyword: keywordFor(payload, "collection"),
      },
      update: {},
    });
  }
}
