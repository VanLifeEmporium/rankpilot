import { load } from 'cheerio';
import { createHash } from 'node:crypto';
import type { Image } from './types';
const tags = /<img\b(?:[^>"']|"[^"]*"|'[^']*')*>/gi;
export function inlineImages(html: string): Image[] {
  return [...html.matchAll(tags)].map((match, index) => {
    const img = load(match[0])('img');
    const url = img.attr('src') || '';
    return {id:`inline:${index}:${createHash('sha256').update(url).digest('hex').slice(0,12)}`,url,alt:img.attr('alt') || '',filename:'inline-image'};
  }).filter(i => i.url.startsWith('https://'));
}
export function updateInlineAlts(html: string, values: {id:string;alt:string}[]) {
  const images = inlineImages(html);
  let index = -1;
  return html.replace(tags, tag => {
    index++;
    const img = images.find(i => i.id.startsWith(`inline:${index}:`));
    const value = img && values.find(v => v.id === img.id);
    if (!value || value.alt === img.alt) return tag;
    const $ = load(tag, {}, false);
    $('img').attr('alt',value.alt);
    return $.html();
  });
}
