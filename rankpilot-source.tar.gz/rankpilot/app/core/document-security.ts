/** Preserve Shopify's shop-specific framing policy; close the no-shop gap. */
export function secureDocument(request: Request, headers: Headers) {
  const policy = headers.get('Content-Security-Policy') || '';
  if (!/(?:^|;)\s*frame-ancestors\s/i.test(policy)) {
    headers.set('Content-Security-Policy', `${policy}${policy ? '; ' : ''}frame-ancestors 'none'`);
  }
  headers.set('X-Content-Type-Options', 'nosniff');
  headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  headers.set('Cache-Control', 'no-store');
  if (new URL(request.url).protocol === 'https:')
    headers.set('Strict-Transport-Security', 'max-age=31536000');
}
