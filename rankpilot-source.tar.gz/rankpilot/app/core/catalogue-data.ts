export const clusters: Record<string, string[]> = {
  Interiors: [
    "campervan interior accessories UK",
    "campervan curtains",
    "van blackout blinds",
    "campervan storage ideas",
    "van conversion accessories",
    "campervan cushions",
    "van interior decor",
  ],
  "Kitchen/Cooking": [
    "campervan kitchen accessories",
    "compact camping cookware",
    "portable camping stove UK",
    "van life kitchen storage",
    "collapsible kitchenware",
  ],
  "Off Grid": [
    "off-grid camping gear UK",
    "portable power station for campervan",
    "leisure battery charger",
    "campervan solar panel kit",
    "12V accessories",
    "water storage for vans",
  ],
  "Best Sellers": [
    "campervan essentials UK",
    "gifts for van lifers",
    "van life accessories UK",
  ],
  Signature: [
    "van life wall art",
    "campervan wood print",
    "gifts for van lifers",
    "camper van gifts UK",
  ],
};
export const prompts = [
  "best portable power station for a campervan UK",
  "where to buy campervan interior accessories UK",
  "gifts for someone who loves van life",
  "best compact cookware for a campervan",
  "campervan wall art UK",
  "essential kit for a first campervan trip",
];
export const topics = [
  "How to power a campervan off grid",
  "Campervan kitchen essentials for small spaces",
  "Best gifts for van lifers",
  "How to keep a campervan warm in a UK winter",
  "Van conversion interior ideas on a budget",
];
export const factLabels: Record<string, string> = {
  dimensions: "Dimensions",
  weight: "Weight",
  materials: "Materials",
  power: "Power requirements",
  compatibility: "Compatibility",
  included: "What is included",
  care: "Care notes",
};

export const opportunities = [
  {
    name: "Quirky Campers · conversion and accessory guides",
    url: "https://www.quirkycampers.com/uk/blog/quirky-campers-blog/",
    angle:
      "Research relevant editorial guides. Offer a sourced small-space kit comparison; no placement is assumed.",
  },
  {
    name: "Wild Camping for Motorhomes forum",
    url: "https://wildcamping.co.uk/forums/",
    angle:
      "Listen to genuine questions about interiors and off-grid equipment before asking moderators about a helpful contribution.",
  },
  {
    name: "r/VanLifeUK",
    url: "https://www.reddit.com/r/VanLifeUK/",
    angle:
      "Use recurring questions to improve product facts. Ask moderators before any commercial posting.",
  },
  {
    name: "VANLIFE HUB",
    url: "https://vanlifehub.co.uk/blog/",
    angle:
      "Explore conversion-focused editorial coverage and whether a verified guide would suit its readers.",
  },
  {
    name: "Motorhome Matt podcast",
    url: "https://podcasts.apple.com/gb/podcast/how-to-convert-a-van-into-a-campervan-on-a/id1599553308?i=1000782009351",
    angle:
      "Research guest suitability. The show has a retail affiliation, so treat this as a potential competitor relationship.",
  },
  {
    name: "Vanlife TV",
    url: "https://vanlife.tv/",
    angle:
      "Review practical product and conversion content before proposing a relevant contribution. No review or link is promised.",
  },
];
