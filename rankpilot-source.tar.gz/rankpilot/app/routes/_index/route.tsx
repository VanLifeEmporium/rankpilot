import { redirect, type LoaderFunctionArgs } from "react-router";
export const loader = ({ request }: LoaderFunctionArgs) => {
  // Keep Shopify's signed launch context, including host and session token.
  return redirect(`/app${new URL(request.url).search}`);
};
