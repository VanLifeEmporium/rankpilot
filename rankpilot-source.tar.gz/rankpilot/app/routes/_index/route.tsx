import { redirect, type LoaderFunctionArgs } from "react-router";
export const loader = ({ request }: LoaderFunctionArgs) => {
  const url = new URL(request.url);
  if (process.env.DEMO_MODE !== "true" && !url.searchParams.has("shop"))
    return null;
  // Keep Shopify's signed launch context, including host and session token.
  return redirect(`/app${new URL(request.url).search}`);
};

export default function Landing() {
  return <main style={{maxWidth: 640, margin: "64px auto", padding: 24, fontFamily: "sans-serif"}}>
    <h1>RankPilot</h1>
    <p>Open RankPilot from your Shopify admin to access your store securely.</p>
    <a href="https://admin.shopify.com">Open Shopify admin</a>
  </main>;
}
