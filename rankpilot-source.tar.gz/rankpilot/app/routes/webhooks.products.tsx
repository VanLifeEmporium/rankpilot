import type { ActionFunctionArgs } from "react-router";
import { authenticate } from "../shopify.server";
import prisma from "../db.server";
export async function action({ request }: ActionFunctionArgs) {
  const { shop, payload } = await authenticate.webhook(request);
  const id = request.headers.get("x-shopify-webhook-id");
  if (!id) return new Response("Missing delivery ID", { status: 400 });
  const store = await prisma.store.findUnique({ where: { id: shop } });
  if (!store?.active) return new Response(null, { status: 200 });
  const productId =
    payload.admin_graphql_api_id || `gid://shopify/Product/${payload.id}`;
  try {
    await prisma.$transaction([
      prisma.webhookReceipt.create({ data: { id, storeId: shop } }),
      prisma.job.create({
        data: {
          storeId: shop,
          kind: "webhook",
          payload: JSON.stringify({ productId }),
          dedup: `${shop}:webhook:${id}`,
        },
      }),
    ]);
  } catch (e) {
    if ((e as { code?: string }).code !== "P2002") throw e;
  }
  return new Response(null, { status: 200 });
}
