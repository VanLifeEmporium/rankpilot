import type { ActionFunctionArgs } from "react-router";
import { authenticate } from "../shopify.server";
import prisma from "../db.server";
export async function action({ request }: ActionFunctionArgs) {
  const { shop } = await authenticate.webhook(request);
  await prisma.$transaction([
    prisma.session.deleteMany({ where: { shop } }),
    prisma.store.updateMany({
      where: { id: shop },
      data: { active: false, credentials: "{}" },
    }),
    prisma.job.updateMany({
      where: { storeId: shop, status: { in: ["queued", "running"] } },
      data: { status: "cancelled" },
    }),
  ]);
  return new Response(null, { status: 200 });
}
