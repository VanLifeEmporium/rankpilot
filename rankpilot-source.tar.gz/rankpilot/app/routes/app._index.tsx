import type { LoaderFunctionArgs, ActionFunctionArgs } from "react-router";
import { loadUI, actionUI } from "../core/ui.server";
export const loader = ({ request }: LoaderFunctionArgs) => loadUI(request);
export const action = ({ request }: ActionFunctionArgs) => actionUI(request);
export { default } from "../components/Workspace";
