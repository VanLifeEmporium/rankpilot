import type { LoaderFunctionArgs } from "react-router";
import { context } from "../core/context.server";
import prisma from "../db.server";
import { llmsText } from "../core/service.server";
import { settings } from "../core/types";
export async function loader({ request }: LoaderFunctionArgs) {
  const { store } = await context(request);
  const u = new URL(request.url);
  let output = "",
    filename = "rankpilot-report.md";
  if (u.searchParams.get("type") === "llms") {
    const resources = await prisma.resource.findMany({
      where: { storeId: store.id },
    });
    output = llmsText(store.domain, resources, settings(store.settings));
    filename = "llms.txt";
  } else if (u.searchParams.get("type") === "changes") {
    output = JSON.stringify(
      await prisma.change.findMany({
        where: { storeId: store.id },
        orderBy: { createdAt: "desc" },
      }),
      null,
      2,
    );
    filename = "rankpilot-change-history.json";
  } else {
    const report = await prisma.report.findFirstOrThrow({
      where: {
        storeId: store.id,
        ...(u.searchParams.get("id") ? { id: u.searchParams.get("id")! } : {}),
      },
      orderBy: { createdAt: "desc" },
    });
    output = report.markdown;
  }
  return new Response(output, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}
