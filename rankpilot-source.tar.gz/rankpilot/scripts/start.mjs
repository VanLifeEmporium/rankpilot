import { spawn } from "node:child_process";
if (
  process.env.DEMO_MODE !== "true" &&
  (!process.env.ENCRYPTION_KEY ||
    !process.env.SESSION_SECRET ||
    !process.env.SHOPIFY_API_KEY ||
    !process.env.SHOPIFY_API_SECRET)
)
  throw new Error("Production secrets are missing");
const children = [
  spawn("npm", ["start"], { stdio: "inherit" }),
  spawn("npm", ["run", "worker"], { stdio: "inherit" }),
];
for (const child of children)
  child.on("exit", (code) => {
    children.forEach((c) => c.kill());
    process.exit(code || 0);
  });
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () => children.forEach((c) => c.kill()));
