import { readFileSync } from "node:fs";
import { toLiquidHtmlAST } from "@shopify/liquid-html-parser";
const liquid = readFileSync(
  "extensions/rankpilot-schema/blocks/rankpilot.liquid",
  "utf8",
);
toLiquidHtmlAST(liquid);
const schema = JSON.parse(
  liquid.match(/{% schema %}([\s\S]*?){% endschema %}/)[1],
);
if (schema.target !== "body") throw new Error("Expected app embed body target");
if (
  new Set(schema.settings.filter((s) => s.id).map((s) => s.id)).size !==
  schema.settings.filter((s) => s.id).length
)
  throw new Error("Duplicate schema setting ID");
const locales = JSON.parse(
  readFileSync("extensions/rankpilot-schema/locales/en.default.json", "utf8"),
);
if (!locales.rankpilot.faq_heading) throw new Error("Missing FAQ translation");
console.log(
  "PASS: Shopify Liquid AST, embedded schema JSON, unique settings and locale keys.",
);
