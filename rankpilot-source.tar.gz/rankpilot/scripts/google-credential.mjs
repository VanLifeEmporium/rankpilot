import { readFileSync, writeFileSync } from "node:fs";
const file = process.argv[2];
if (!file)
  throw new Error(
    "Usage: node scripts/google-credential.mjs /path/service-account.json",
  );
const content = readFileSync(file, "utf8");
const account = JSON.parse(content);
if (!account.private_key || !account.client_email)
  throw new Error("Not a service account key");
writeFileSync(
  "google-credential-update.json",
  JSON.stringify({ googleServiceAccount: content }, null, 2),
  { mode: 0o600 },
);
console.log(
  "Created google-credential-update.json. Keep it private and delete after saving in RankPilot Settings.",
);
