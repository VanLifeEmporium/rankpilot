import { spawnSync, spawn } from "node:child_process";
import { existsSync, writeFileSync } from "node:fs";
import { randomBytes } from "node:crypto";
if (!existsSync(".env"))
  writeFileSync(
    ".env",
    `DATABASE_URL="file:./rankpilot.sqlite"\nDEMO_MODE=true\nSHOPIFY_APP_URL=http://localhost:3000\nENCRYPTION_KEY=${randomBytes(32).toString("hex")}\nSESSION_SECRET=${randomBytes(32).toString("hex")}\n`,
  );
process.loadEnvFile(".env");
if (process.env.DEMO_MODE !== "true")
  throw new Error(
    "Use demo with DEMO_MODE=true. Do not replace live configuration.",
  );
const setup = spawnSync("npm", ["run", "setup"], {
  stdio: "inherit",
  shell: process.platform === "win32",
});
if (setup.status) process.exit(setup.status);
const children = [
  spawn("npm", ["run", "dev:local"], {
    stdio: "inherit",
    shell: process.platform === "win32",
  }),
  spawn("npm", ["run", "worker"], {
    stdio: "inherit",
    shell: process.platform === "win32",
  }),
];
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () => {
    children.forEach((c) => c.kill());
    process.exit(0);
  });
