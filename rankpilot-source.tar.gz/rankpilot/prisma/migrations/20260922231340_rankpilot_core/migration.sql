-- CreateTable
CREATE TABLE "Store" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "demo" BOOLEAN NOT NULL DEFAULT false,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "domain" TEXT NOT NULL DEFAULT 'https://vanlifeemporium.com',
    "settings" TEXT NOT NULL DEFAULT '{}',
    "credentials" TEXT NOT NULL DEFAULT '{}',
    "discoveries" TEXT NOT NULL DEFAULT '{}',
    "nextWeekly" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "Resource" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "storeId" TEXT NOT NULL,
    "remoteId" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "handle" TEXT NOT NULL,
    "collection" TEXT NOT NULL DEFAULT '',
    "payload" TEXT NOT NULL,
    "facts" TEXT NOT NULL DEFAULT '{}',
    "keyword" TEXT NOT NULL DEFAULT '',
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "Audit" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "storeId" TEXT NOT NULL,
    "score" INTEGER NOT NULL,
    "aeoScore" INTEGER NOT NULL,
    "resourceCount" INTEGER NOT NULL,
    "issues" TEXT NOT NULL,
    "coverage" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "Change" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "storeId" TEXT NOT NULL,
    "resourceId" TEXT NOT NULL,
    "feature" TEXT NOT NULL,
    "before" TEXT NOT NULL,
    "after" TEXT NOT NULL,
    "reasons" TEXT NOT NULL DEFAULT '[]',
    "blockers" TEXT NOT NULL DEFAULT '[]',
    "status" TEXT NOT NULL DEFAULT 'pending',
    "error" TEXT,
    "approvedBy" TEXT,
    "appliedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "Job" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "storeId" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "payload" TEXT NOT NULL DEFAULT '{}',
    "dedup" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'queued',
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "runAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lockedAt" DATETIME,
    "error" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "Event" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "storeId" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "detail" TEXT NOT NULL DEFAULT '{}',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "Observation" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "storeId" TEXT NOT NULL,
    "engine" TEXT NOT NULL,
    "prompt" TEXT NOT NULL,
    "model" TEXT NOT NULL,
    "text" TEXT NOT NULL,
    "citations" TEXT NOT NULL,
    "competitors" TEXT NOT NULL,
    "mentioned" BOOLEAN NOT NULL,
    "cited" BOOLEAN NOT NULL,
    "source" TEXT NOT NULL DEFAULT 'API sample',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "Metric" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "storeId" TEXT NOT NULL,
    "provider" TEXT NOT NULL,
    "period" TEXT NOT NULL,
    "payload" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "Report" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "storeId" TEXT NOT NULL,
    "markdown" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "WebhookReceipt" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "storeId" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateIndex
CREATE INDEX "Resource_storeId_kind_idx" ON "Resource"("storeId", "kind");

-- CreateIndex
CREATE UNIQUE INDEX "Resource_storeId_remoteId_key" ON "Resource"("storeId", "remoteId");

-- CreateIndex
CREATE INDEX "Audit_storeId_createdAt_idx" ON "Audit"("storeId", "createdAt");

-- CreateIndex
CREATE INDEX "Change_storeId_status_idx" ON "Change"("storeId", "status");

-- CreateIndex
CREATE UNIQUE INDEX "Job_dedup_key" ON "Job"("dedup");

-- CreateIndex
CREATE INDEX "Job_status_runAt_idx" ON "Job"("status", "runAt");

-- CreateIndex
CREATE INDEX "Event_storeId_createdAt_idx" ON "Event"("storeId", "createdAt");

-- CreateIndex
CREATE INDEX "Observation_storeId_createdAt_idx" ON "Observation"("storeId", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "Metric_storeId_provider_period_key" ON "Metric"("storeId", "provider", "period");

-- CreateIndex
CREATE INDEX "Report_storeId_createdAt_idx" ON "Report"("storeId", "createdAt");
