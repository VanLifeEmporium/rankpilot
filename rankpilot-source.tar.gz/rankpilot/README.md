# RankPilot

Embedded Shopify SEO and answer-readiness app for Van Life Emporium. Built on Shopify's official React Router template, App Bridge and Polaris web components, with Prisma persistence and a background worker.

## Run the working demo

Install Node 22.17+ or Node 24, unzip this project, open a terminal in the `rankpilot` folder, then:

```sh
npm ci
npm run demo
```

Open **http://localhost:3000**. The command creates a local `.env` with random secrets on first run, applies database migrations, starts the web app and starts the worker. Demo mode has six sample products and five collections. Each browser gets a separate signed-cookie workspace. No Shopify installation or AI key is needed. Demo specifications and illustrations are not claims about actual stock.

Try this flow:
1. Open Products. Select a product and generate a search-snippet preview.
2. Open Audit → Approval queue. Compare the before/after content and approve it.
3. Open Reports → Version history. Roll the change back.
4. Open a product's Facts & keyword form. Confirm facts, then generate a description or FAQ.
5. Create a guide in Content. It is saved as an unpublished draft.
6. Turn on an individual Autopilot option in Settings and generate a change for that feature.

## Install in Shopify

Read **[docs/CREDENTIALS.md](docs/CREDENTIALS.md)** for the complete account, hosting, keys, permissions and installation guide. Read **[docs/IMPLEMENTATION.md](docs/IMPLEMENTATION.md)** for coverage, architecture and current limitations.

The app source is ready to configure. It has **not** been installed in Van Life Emporium and has not passed a live OAuth / theme / provider acceptance test. Hosting the app, linking a real Shopify app ID, publishing the extension and installing it are separate steps. No live store data was modified during this build.

## Included

- Dashboard, Audit, Products, Collections, Content, AEO, Reports and Settings.
- Shopify-managed installation/authentication through the official library; encrypted offline sessions; product webhook verification and deduplication.
- Paginated catalogue import and storefront audit with explicit coverage limits.
- UK keyword clusters, one primary keyword per page and cannibalisation warnings.
- Fact-led product and collection copy, metadata, image labels, filenames, handles, redirects, FAQs and internal links.
- Per-feature approval/autopilot, before/after and snippet previews, persistent versions, protected-field allowlists, stale-edit checks and rollback.
- Unpublished blog drafts with source references and manual-verification markers.
- Theme app embed for structured data and visible FAQs, with existing-schema detection.
- AI crawler checks, managed `llms.txt` detection and a generated download.
- Search Console, GA4, Merchant API, Bing and PageSpeed adapters.
- OpenAI, Perplexity and Gemini API visibility samples; separate manual Copilot and AI Overview observations.
- Weekly jobs, reports, non-overlapping period comparisons and guarded underperformance re-queueing.

## Checks

```sh
npm run typecheck
DATABASE_URL=file:./test.sqlite npx prisma migrate deploy
npm test
npm run validate:local
npm run test:ui
```

The `DATABASE_URL=...` command above is for POSIX shells. In PowerShell, set `$env:DATABASE_URL = 'file:./test.sqlite'` before the Prisma command, then remove it before starting the demo. Unit tests set their own test database environment. The bundled browser smoke runner uses a portable Linux Chromium build; run it in Linux or the supplied Docker environment.

- Unit tests cover factual gating, protected fields, encryption, tenant isolation, approval, rollback, conflicts, partial image batches, GraphQL shape and analytics periods.
- Local extension checks parse the Shopify Liquid AST and schema JSON.
- Browser smoke checks cover desktop/mobile rendering, preview generation, approval, rollback, draft creation, AEO and settings.
- Core GraphQL operations were checked against Shopify's schema. The remaining online UI/Liquid validator was blocked by automatic approval review because it uploads source code to Shopify. Local syntax/build checks are included instead. CLI configuration validation still requires the real linked Shopify app.

## Deployment

Use the included Dockerfile/Compose service or a Node host with a persistent local disk. Set `DEMO_MODE=false`, use an HTTPS app URL, configure `.env.example`, then:

```sh
npm run setup
npm run build
npm run start:all
```

`start:all` runs both the web app and background worker. Jobs do not run when the worker is stopped. One host, one worker and persistent SQLite are the supported deployment topology for this package. Back up the database and protect the encryption key separately.

`shopify app deploy` publishes app configuration and extensions, not the Node server. Do not enable Autopilot on a live store until you have reviewed representative changes and tested rollback on a development product.
